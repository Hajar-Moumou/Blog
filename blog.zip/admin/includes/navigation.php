<nav class="navbar navbar-expand-lg navbar-dark bg-dark px-md-5 p-3">
    <a class="navbar-brand" href="http://localhost/php/blog/blog/admin/index.php">Admin</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item mr-2 active">
                <a class="nav-link" href="http://localhost/php/blog/blog/admin/index.php">Posts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="http://localhost/php/blog/blog/admin/categories.php">Categories</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="http://localhost/php/blog/blog/admin/comments.php">Comments</a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link btn btn-danger btn-sm text-white" href="http://localhost/php/blog/blog/admin/logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>